<?php
$name = $_POST['name'];
$VISITOR_EMAIL = $_POST['email'];
$SUBJECT = $_POST['subject'];
$MESSAGE = $_POST['message'];

$email_form = 'suhas@gmail.com';

$email_subject = 'New Form Submission';

$email_body = "User Name: $name.\n".
"User Email: $visitor_email.\n".
"Subject: $subject.\n".
"User Email: $message.\n";

$to = 'suhasgejji10@gmail.com';

$headers = "From: $email_from \r\n";

$headers .="Reply-To:$visitor_email \r\n";

mail($to,$email_subject,$email_body,$headers);

header("Location: contact.html");

?>